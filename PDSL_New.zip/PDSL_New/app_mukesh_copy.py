#!/usr/bin/env python
# coding: utf-8

#library Import
import numpy as np
import pandas as pd
import pickle
#import flask
from flask import Flask, request
#from flask_restplus import reqparse, abort, Api, Resource
from sklearn.preprocessing import OneHotEncoder

app = Flask(__name__)
#flask_app = Api(app = app)
#       version = "1.0",
#       title = "Promise Date Prediction",
#       description = "Promise Date Prediction")

#name_space = flask_app.namespace('pdsl', description='PDSL Prediction APIs')

# @app.route('/json_example',methods=['POST']))

#class MainClass(Resource):
def read_inputdata():
    formData = request.json
    request_data = pd.io.json.json_normalize(formData)
    return request_data

# Data Preprocessing
def data_preprocessing():
    data1 = pd.read_excel('test_data.xlsx')
    # data1=data1.loc[data1["FLOW_STATUS_CODE"]=="CLOSED"]
    drop_columns = ['MODEL_STRING', 'ECCN', 'END_USE', 'SIC_CODE', 'HTSN', 'EXPORT_FLAG', 'REASON_FOR_SUSPICION',
                    'SHIP_SET', 'HOLD_APPLIED_BY', 'HOLD_RELEASED_BY']
    data = data1.drop(drop_columns, axis=1)
    data = data[data['PROMISE_DATE'].notnull()].drop_duplicates()
    data["hold_applied"] = data["HOLD_NAME"].apply(lambda x: '1' if x != "" else '0')
    # holds_data
    holds_data = data.drop(
        ['HOLD_NAME', 'HOLD_CREATION_DATE', 'HOLD_RELEASE_DATE', 'DELIVERY_ID', 'REQUESTED_QUANTITY',
         'PICKED_QUANTITY'], axis=1).drop_duplicates()
    joindata = holds_data.groupby(["LINE_ID"]).agg({"SHIPPED_QUANTITY": 'sum', "ORDERED_QUANTITY": 'sum'})
    main_data = holds_data.drop(["SHIPPED_QUANTITY", "ORDERED_QUANTITY"], axis=1).drop_duplicates()
    final_data = main_data.merge(joindata, on='LINE_ID', how='left')
    final_data["PROMISE_DATE"] = pd.to_datetime(final_data["PROMISE_DATE"])
    final_data["ULTIMATE_DROPOFF_DATE"] = pd.to_datetime(final_data["ULTIMATE_DROPOFF_DATE"])
    final_data["ORDERED_DATE"] = pd.to_datetime(final_data["ORDERED_DATE"])
    # final_data["label"]=(final_data['ULTIMATE_DROPOFF_DATE']-final_data['ORDERED_DATE'])/np.timedelta64(1, 'D')
    join_data = final_data[
        ["LINE_ID", "ORDERED_DATE", "PROMISE_DATE", 'OE_TRANSACTION_TYPES', 'ORDERED_ITEM', 'ULTIMATE_DEST',
         'END_USER_SPECIFIC_PRODUCTS']]
    final_data = final_data[final_data.columns.drop(list(final_data.filter(regex='DATE')))]
    final_data = final_data.drop(
        ["ORDER_NUMBER", "ORG_ID", "HEADER_ID", "FLOW_STATUS_CODE", "SOURCE_TYPE_CODE", "HEADER_ID_1"], axis=1)
    final_data = final_data.apply(lambda x: x.fillna(x.value_counts().index[0]))
    #enc = pickle.load(open("C:\\Users\\manohara.a\\OneDrive - SLK SOFTWARE\\pdsl\\pdsl_enc.pkl", "rb"))
    enc = pickle.load(open("pdsl_enc.pkl", "rb"))
    encoded_data = enc.transform(final_data[
                                     ['OE_TRANSACTION_TYPES', 'ITEM_TYPE_CODE', 'ORDERED_ITEM', 'ULTIMATE_DEST',
                                      'END_USER_SPECIFIC_PRODUCTS', 'SHIPPING_METHOD_CODE', 'SHIP_TO_COUNTRY',
                                      'SHIP_FROM_COUNTRY', 'SHIP_FROM_COUNTRY']]).toarray()
    encoded_data = pd.DataFrame(encoded_data, columns=enc.get_feature_names())
    X = final_data.join(encoded_data).drop(
        ['OE_TRANSACTION_TYPES', 'ITEM_TYPE_CODE', 'ORDERED_ITEM', 'ULTIMATE_DEST', 'END_USER_SPECIFIC_PRODUCTS',
         'SHIPPING_METHOD_CODE', 'SHIP_TO_COUNTRY', 'SHIP_FROM_COUNTRY', 'SHIP_FROM_COUNTRY'], axis=1)
    return X, join_data

# def get(self):
#     return { "status": "Got new data" }
@app.route('/pdsl_prediction',methods=['GET'])
def pdsl_prediction():
    #request_data = read_inputdata()
    #model = pickle.load(open("C:\\Users\\manohara.a\\OneDrive - SLK SOFTWARE\\pdsl\\pdsl_dtree.pkl", "rb"))
    model = pickle.load(open("pdsl_dtree.pkl", "rb"))
    X, join_data = data_preprocessing()

    pred = model.predict(X)
    join_data['pred'] = pred
    temp = join_data['pred'].apply(lambda x: pd.Timedelta(x, unit='D'))
    join_data["predicted_date"] = join_data['ORDERED_DATE'] + temp
    join_data["Expected_Delay"] = (join_data['predicted_date'] - join_data['PROMISE_DATE'])
    join_data["Expected_Delay"]=join_data["Expected_Delay"].astype(str)

    #df_list = join_data.values.tolist()
    json=join_data.to_json(orient='records')
    return json