export class Users
{
    LINE_ID:string;
    ORDERED_DATE:string;
    PROMISE_DATE:Date;
    OE_TRANSACTION_TYPES:string;
    ORDERED_ITEM:string;
    ULTIMATE_DEST:string;
    END_USER_SPECIFIC_PRODUCTS:string;
    pred:string;
    predicted_date:string;
    Expected_Delay:string;
    constructor(LINE_ID, ORDERED_DATE, PROMISE_DATE, OE_TRANSACTION_TYPES, ORDERED_ITEM, ULTIMATE_DEST, END_USER_SPECIFIC_PRODUCTS, pred, predicted_date, Expected_Delay)
    {
      this.LINE_ID=LINE_ID;
      this.ORDERED_DATE=ORDERED_DATE;
      this.PROMISE_DATE=PROMISE_DATE;
      this.OE_TRANSACTION_TYPES=OE_TRANSACTION_TYPES;
      this.ORDERED_ITEM=ORDERED_ITEM;
      this.ULTIMATE_DEST=ULTIMATE_DEST;
      this.END_USER_SPECIFIC_PRODUCTS=END_USER_SPECIFIC_PRODUCTS;
      this.pred=pred;
      this.predicted_date=predicted_date;
      this.Expected_Delay=Expected_Delay; 
    }
}