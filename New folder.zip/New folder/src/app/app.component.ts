import { Component, OnInit } from '@angular/core';
import { RestService } from './rest.service';
import { Users } from './users';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'] 
})

export class AppComponent implements OnInit{

  constructor(private rs : RestService) { }
  
  columns = ["LINE_ID", "ORDERED_DATE", "PROMISE_DATE", "OE_TRANSACTION_TYPES", "ORDERED_ITEM", "ULTIMATE_DEST", "END_USER_SPECIFIC_PRODUCTS", "pred", "predicted_date", "Expected_Delay"];
  index = ["LINE_ID", "ORDERED_DATE", "PROMISE_DATE", "OE_TRANSACTION_TYPES", "ORDERED_ITEM", "ULTIMATE_DEST", "END_USER_SPECIFIC_PRODUCTS", "pred", "predicted_date", "Expected_Delay"];

  users: Users[] = [];

  ngOnInit(): void {
    this.rs.getUsers().subscribe
    (
      (response) => 
      {
        this.users = response;
        console.log(this.users)
        
        //print(response)
      },
      (error) => console.log(error)
    )
  }
}
