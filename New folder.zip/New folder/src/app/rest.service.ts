import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Users } from './Users';
@Injectable({
  providedIn: 'root'
})
export class RestService {
  constructor(private http : HttpClient) { }
  url : string = "http://127.0.0.1:5000/pdsl_prediction"
  getUsers()
  {
    return this.http.get<Users[]>(this.url);
    //return this.http.get(this.url);
  }
}