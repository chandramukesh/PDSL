import { UploadData } from './upload-data';

describe('UploadData', () => {
  it('should create an instance', () => {
    expect(new UploadData()).toBeTruthy();
  });
});
