import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-screen-one',
  templateUrl: './screen-one.component.html',
  styleUrls: ['./screen-one.component.css']
})
export class ScreenOneComponent implements OnInit {

  constructor(private router: Router) {}

  ngOnInit() {}
  onclick($event) {
    this.router.navigate(['SecondScreen']);
  }
}
