import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ScreenTwoComponent } from './screen-two/screen-two.component';
import { ScreenOneComponent } from './screen-one/screen-one.component';
import { UploadPageComponent } from './upload-page/upload-page.component';


const routes: Routes = [
  {path: '', component: UploadPageComponent},
  {path: 'FirstScreen', component: ScreenOneComponent},
  {path: 'SecondScreen', component: ScreenTwoComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {
 }
