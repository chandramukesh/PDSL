import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import * as XLSX from 'xlsx';
import { UploadService } from '../upload.service';

@Component({
  selector: 'app-upload-page',
  templateUrl: './upload-page.component.html',
  styleUrls: ['./upload-page.component.css']
})
export class UploadPageComponent implements OnInit {
  willDownload = false;
  dataString: object;
  constructor( private router: Router, private uploadService: UploadService) { }

  ngOnInit() {
  }

  onFileChange(ev) {
    let workBook = null;
    let jsonData = null;
    const reader = new FileReader();
    const file = ev.target.files[0];
    reader.onload = (event) => {
      const data = reader.result;
      workBook = XLSX.read(data, { type: 'binary' });
      jsonData = workBook.SheetNames.reduce((initial, name) => {
        const sheet = workBook.Sheets[name];
        initial[name] = XLSX.utils.sheet_to_json(sheet);
        return initial;
      }, {});
      const dataString = JSON.stringify(jsonData);
      console.log(dataString);
      // document.getElementById('output').innerHTML = dataString.slice(0, 300).concat('...');
      // this.setDownload(dataString);
    };
    reader.readAsBinaryString(file);
    this.uploadService.uplaodData(this.dataString).subscribe(data => {
      console.log(data);
      }, error => {console.log(error); });
  }

  // setDownload(data) {
  //   this.willDownload = true;
  //   setTimeout(() => {
  //     const el = document.querySelector('#download');
  //     el.setAttribute('href', `data:text/json;charset=utf-8,${encodeURIComponent(data)}`);
  //     el.setAttribute('download', 'xlsxtojson.json');
  //   }, 1000);
  // }

  onUpload($event) {
    // tslint:disable-next-line: no-debugger
    debugger;
    this.router.navigate(['FirstScreen']);
  }


}
