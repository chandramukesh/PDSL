import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-screen-two',
  templateUrl: './screen-two.component.html',
  styleUrls: ['./screen-two.component.css']
})
export class ScreenTwoComponent implements OnInit {

  constructor(private router: Router) { }

  ngOnInit() {
  }

  onBack($event) {
    this.router.navigate(['FirstScreen']);
  }
}
