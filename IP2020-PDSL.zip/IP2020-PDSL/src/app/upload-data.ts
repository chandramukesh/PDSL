export class UploadData {

}
